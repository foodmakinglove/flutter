import 'package:flutter/material.dart';

class Beranda extends StatelessWidget {
  const Beranda ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Selamat Datang, Amira'),
        backgroundColor: Colors.pink.shade200,
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Mau masak apa hari ini?',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
          ),
          // Kategori Menu
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CategoryButton(title: 'Sarapan', icon: Icons.breakfast_dining),
                CategoryButton(title: 'Makan Siang', icon: Icons.lunch_dining),
                CategoryButton(title: 'Makan Malam', icon: Icons.dinner_dining),
                CategoryButton(title: 'Puding', icon: Icons.cake),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Menu Hari ini',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          // Daftar Menu
          Expanded(
            child: ListView(
              padding: EdgeInsets.symmetric(horizontal: 16.0),
              children: [
                RecipeCard(
                  title: 'Capcay',
                  time: '25 min',
                  imageUrl: 'https://example.com/capcay.jpg',
                ),
                RecipeCard(
                  title: 'Soto Ayam',
                  time: '50 min',
                  imageUrl: 'https://example.com/soto_ayam.jpg',
                ),
                RecipeCard(
                  title: 'Bakso',
                  time: '45 min',
                  imageUrl: 'https://example.com/bakso.jpg',
                ),
                RecipeCard(
                  title: 'Kimbab',
                  time: '45 min',
                  imageUrl: 'https://example.com/kimbab.jpg',
                ),
                RecipeCard(
                  title: 'Nasi Goreng',
                  time: '20 min',
                  imageUrl: 'https://example.com/nasi_goreng.jpg',
                ),
                RecipeCard(
                  title: 'Sup Buntut',
                  time: '40 min',
                  imageUrl: 'https://example.com/sup_buntut.jpg',
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favorite',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

// Widget untuk Kategori Tombol
class CategoryButton extends StatelessWidget {
  final String title;
  final IconData icon;

  const CategoryButton({
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 16.0),
      child: Column(
        children: [
          CircleAvatar(
            backgroundColor: Colors.pink.shade100,
            radius: 30,
            child: Icon(icon, color: Colors.white),
          ),
          SizedBox(height: 8),
          Text(title, style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}

// Widget untuk Kartu Resep
class RecipeCard extends StatelessWidget {
  final String title;
  final String time;
  final String imageUrl;

  const RecipeCard({
    required this.title,
    required this.time,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      margin: EdgeInsets.symmetric(vertical: 8.0),
      child: ListTile(
        leading:
            Image.network(imageUrl, width: 50, height: 50, fit: BoxFit.cover),
        title: Text(title),
        subtitle: Text(time),
      ),
    );
  }
}