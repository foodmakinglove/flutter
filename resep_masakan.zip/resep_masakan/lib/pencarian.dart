import 'package:flutter/material.dart';

class Pencarian extends StatelessWidget {
  const Pencarian ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink.shade200,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {},
        ),
        title: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Mau masak apa hari ini?',
              border: InputBorder.none,
              prefixIcon: Icon(Icons.search, color: Colors.black54),
              contentPadding: EdgeInsets.symmetric(vertical: 12.0),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Hasil Pencarian
              Text(
                'Hasil pencarian kamu',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Wrap(
                spacing: 8.0,
                runSpacing: 8.0,
                children: [
                  SearchChip(label: 'Rica-Rica ayam'),
                  SearchChip(label: 'Mie ayam'),
                  SearchChip(label: 'Tumis kangkung'),
                  SearchChip(label: 'Seblak'),
                ],
              ),
              SizedBox(height: 16),
              // Kategori Masakan
              Text(
                'Kategori Masakan',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Wrap(
                spacing: 8.0,
                runSpacing: 8.0,
                children: [
                  CategoryChip(label: 'Bersantan'),
                  CategoryChip(label: 'Tumis'),
                  CategoryChip(label: 'Sup'),
                  CategoryChip(label: 'Puding'),
                ],
              ),
              SizedBox(height: 16),
              // Masakan Rekomendasi
              Text(
                'Masakan rekomendasi',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  RecipeCard(
                    title: 'Nasi kuning',
                    imageUrl:
                        'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/Nasi_Kuning.JPG/640px-Nasi_Kuning.JPG',
                    rating: '★★★★☆',
                  ),
                  RecipeCard(
                    title: 'Klepon',
                    imageUrl:
                        'https://upload.wikimedia.org/wikipedia/commons/8/89/Klepon.jpg',
                    rating: '★★★★☆',
                  ),
                  RecipeCard(
                    title: 'Telur balado',
                    imageUrl:
                        'https://upload.wikimedia.org/wikipedia/commons/f/f3/Telur_balado.JPG',
                    rating: '★★★★★',
                  ),
                  RecipeCard(
                    title: 'Bubur sum-sum',
                    imageUrl:
                        'https://upload.wikimedia.org/wikipedia/commons/7/75/Bubur_sum_sum.jpg',
                    rating: '★★★★☆',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favorite',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

// Widget untuk SearchChip
class SearchChip extends StatelessWidget {
  final String label;

  const SearchChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label),
      backgroundColor: Colors.pink.shade100,
    );
  }
}

// Widget untuk Kategori Masakan
class CategoryChip extends StatelessWidget {
  final String label;

  const CategoryChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label),
      backgroundColor: Colors.pink.shade300,
    );
  }
}

// Widget untuk Kartu Resep
class RecipeCard extends StatelessWidget {
  final String title;
  final String imageUrl;
  final String rating;

  const RecipeCard({
    required this.title,
    required this.imageUrl,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 1,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.vertical(top: Radius.circular(10.0)),
            child: Image.network(
              imageUrl,
              width: double.infinity,
              height: 100,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Text(
                  rating,
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}