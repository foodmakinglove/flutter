import 'package:flutter/material.dart';

class Profiladmin extends StatelessWidget {
  const Profiladmin ({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink.shade200,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {},
        ),
        title: Text('Profil'),
        actions: [
          TextButton(
            onPressed: () {},
            child: Text(
              'Simpan',
              style: TextStyle(color: Colors.redAccent, fontSize: 16),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Foto Profil
              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: NetworkImage(
                        'https://example.com/profile_picture.jpg'), // Ganti dengan URL gambar profil
                  ),
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () {},
                  ),
                ],
              ),
              SizedBox(height: 16),
              // Form Data Profil
              ProfileField(
                label: 'Nama Depan',
                initialValue: 'Aulia Eka',
              ),
              ProfileField(
                label: 'Nama Belakang',
                initialValue: 'Putri',
              ),
              ProfileField(
                label: 'Tanggal Lahir',
                initialValue: '25 Agustus 1998',
                isDateField: true,
              ),
              ProfileField(
                label: 'Jenis Kelamin',
                initialValue: 'Perempuan',
              ),
              ProfileField(
                label: 'No. Handphone',
                initialValue: '088569756253',
              ),
              ProfileField(
                label: 'E-mail',
                initialValue: 'auliakaputrig@gmail.com',
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favorite',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

// Widget untuk menampilkan setiap field profil
class ProfileField extends StatelessWidget {
  final String label;
  final String initialValue;
  final bool isDateField;

  const ProfileField({
    required this.label,
    required this.initialValue,
    this.isDateField = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        initialValue: initialValue,
        decoration: InputDecoration(
          labelText: label,
          suffixIcon: isDateField ? Icon(Icons.calendar_today) : null,
          filled: true,
          fillColor: Colors.grey.shade200,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: BorderSide.none,
          ),
        ),
        readOnly: isDateField,
      ),
    );
  }
}