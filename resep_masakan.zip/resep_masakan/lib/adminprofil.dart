import 'package:flutter/material.dart';

class AdminProfil extends StatelessWidget {
  const AdminProfil ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200], // Background utama
      appBar: AppBar(
        backgroundColor: Colors.brown[100], // Warna header
        elevation: 0,
        title: Text(
          'Admin',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.settings, color: Colors.black),
            onPressed: () {
              // Aksi untuk membuka pengaturan
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Welcome Text
              Text(
                'Selamat Datang, Aulia',
                style: TextStyle(
                  fontSize: 22,
                  color: Colors.brown[900],
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),

              // Profile Picture
              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: AssetImage(
                        'assets/images/admin_profile.jpg'), // Gambar profil admin
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: IconButton(
                      icon: Icon(Icons.edit, color: Colors.black),
                      onPressed: () {
                        // Aksi edit foto profil
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(height: 30),

              // Statistik Total Resep
              _buildStatCard('Total Resep', '50', Colors.blue, Icons.add),
              SizedBox(height: 15),

              // Statistik Total Kategori
              _buildStatCard('Total Kategori', '4', Colors.green, null),
              SizedBox(height: 15),

              // Statistik Total Pengguna
              _buildStatCard('Total Pengguna', '75', Colors.purple, null),
              SizedBox(height: 15),

              // Statistik Total Admin
              _buildStatCard('Total Admin', '1', Colors.yellow, null),
            ],
          ),
        ),
      ),
      // Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.grey[300],
        selectedItemColor: Colors.brown,
        unselectedItemColor: Colors.black54,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.receipt),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: '',
          ),
        ],
      ),
    );
  }

  // Widget for the statistic card
  Widget _buildStatCard(
      String title, String count, Color color, IconData? icon) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (icon != null) // Add icon if available
                  Icon(icon, size: 18),
              ],
            ),
            Row(
              children: [
                Text(
                  count,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
